# WinDesign Next

基于 Vue 3 的企业级 UI 组件库，为卫宁健康业务前端提供高质量的通用组件与开发规范。

## 特性

- **Vue 3 + TypeScript** — 基于 Composition API 与 `<script setup>`，完整的类型推导支持
- **83+ 通用组件** — 覆盖表单、数据展示、导航、反馈等常见业务场景
- **主题定制** — CSS Variables + SCSS，支持暗黑模式与品牌色定制
- **国际化** — 内置 8 种语言（简体中文、繁体中文、英语、西班牙语、葡萄牙语、越南语等）
- **按需引入** — 支持 Tree-shaking，配合自动导入插件实现零样板代码
- **无障碍** — 遵循 WAI-ARIA 规范，内置键盘导航与屏幕阅读器支持

## 环境要求

| 依赖     | 版本要求   |
| -------- | ---------- |
| Node.js  | >= 20.19.0 |
| Vue      | ^3.3.0     |
| Sass     | >= 1.79.0  |
| 包管理器 | pnpm 10.x  |

浏览器支持：Chrome >= 85 / Edge >= 85 / Firefox >= 79 / Safari >= 14.1（不支持 IE11）

## 安装

组件库发布在公司内部 npm 仓库，需先配置 registry：

```bash
npm config set registry http://172.16.9.57:8081/repository/npm-group/
```

安装组件库：

```bash
# pnpm（推荐）
pnpm add win-design-next

# npm
npm install win-design-next --save

# yarn
yarn add win-design-next
```

## 快速上手

### 完整引入

```ts
// main.ts
import { createApp } from 'vue'
import WinDesignNext from 'win-design-next'
import 'win-design-next/dist/index.css'
import App from './App.vue'

const app = createApp(App)
app.use(WinDesignNext)
app.mount('#app')
```

## 组件总览

### 基础

| 组件           | 说明                 |
| -------------- | -------------------- |
| ConfigProvider | 全局配置             |
| Button         | 按钮                 |
| Icon           | 图标                 |
| Container      | 布局容器             |
| Row / Col      | 栅格布局             |
| Layout         | 布局                 |
| Divider        | 分割线               |
| Space          | 间距                 |
| Scrollbar      | 滚动条               |
| Typography     | 排版（Text / Title） |

### 导航

| 组件       | 说明       |
| ---------- | ---------- |
| Affix      | 固钉       |
| Anchor     | 锚点       |
| Breadcrumb | 面包屑     |
| Dropdown   | 下拉菜单   |
| Menu       | 导航菜单   |
| Pagination | 分页       |
| Steps      | 步骤条     |
| Tabs       | 标签页     |
| Tour       | 漫游式引导 |

### 表单录入

| 组件             | 说明           |
| ---------------- | -------------- |
| Autocomplete     | 自动补全输入   |
| Cascader         | 级联选择器     |
| CascaderPanel    | 级联面板       |
| Checkbox         | 多选框         |
| ColorPicker      | 颜色选择器     |
| ColorPickerPanel | 颜色选择面板   |
| DatePicker       | 日期选择器     |
| DatePickerPanel  | 日期选择面板   |
| Form             | 表单           |
| Input            | 输入框         |
| InputNumber      | 数字输入框     |
| InputTag         | 标签输入框     |
| Mention          | 提及           |
| Radio            | 单选框         |
| Rate             | 评分           |
| Select           | 选择器         |
| SelectV2         | 虚拟滚动选择器 |
| Slider           | 滑块           |
| Switch           | 开关           |
| TimePicker       | 时间选择器     |
| TimeSelect       | 时间选择       |
| Transfer         | 穿梭框         |
| TreeSelect       | 树形选择器     |
| Upload           | 上传           |

### 数据展示

| 组件           | 说明         |
| -------------- | ------------ |
| Avatar         | 头像         |
| Badge          | 徽标         |
| Calendar       | 日历         |
| Card           | 卡片         |
| Carousel       | 走马灯       |
| Collapse       | 折叠面板     |
| Countdown      | 倒计时       |
| Descriptions   | 描述列表     |
| Empty          | 空状态       |
| Image          | 图片         |
| ImageViewer    | 图片查看器   |
| List           | 列表         |
| Popconfirm     | 气泡确认框   |
| Popover        | 气泡卡片     |
| Progress       | 进度条       |
| Skeleton       | 骨架屏       |
| Statistic      | 统计数值     |
| Table          | 表格         |
| TableV2        | 虚拟滚动表格 |
| TableSelect    | 表格选择器   |
| Tag / CheckTag | 标签         |
| Timeline       | 时间线       |
| Tooltip        | 文字提示     |
| Tree           | 树形控件     |
| TreeV2         | 虚拟滚动树   |
| VirtualList    | 虚拟列表     |
| Watermark      | 水印         |
| Status         | 状态         |
| Segmented      | 分段控制器   |

### 反馈

| 组件         | 说明     |
| ------------ | -------- |
| Alert        | 警告     |
| Dialog       | 对话框   |
| Drawer       | 抽屉     |
| Loading      | 加载     |
| LoadingBall  | 加载球   |
| Message      | 消息提示 |
| MessageBox   | 消息弹框 |
| Modal        | 模态框   |
| Notification | 通知     |
| Overlay      | 遮罩层   |
| Result       | 结果     |

### 其他

| 组件       | 说明     |
| ---------- | -------- |
| Backtop    | 回到顶部 |
| FakeArrow  | 仿箭头   |
| Link       | 链接     |
| PageHeader | 页头     |
| Splitter   | 分割面板 |

### 指令

| 指令            | 说明     |
| --------------- | -------- |
| vLoading        | 加载指令 |
| vInfiniteScroll | 无限滚动 |

## Sass 配置

如果项目使用 Sass 且终端出现 `legacy JS API Deprecation Warning`，在 `vite.config.ts` 中添加：

```ts
export default defineConfig({
  css: {
    preprocessorOptions: {
      scss: { api: 'modern-compiler' },
    },
  },
})
```

## 兼容模式（Compat）注意

如果项目启用了 Vue 3 的兼容模式（compat），组件的 `v-model` 绑定可能失效，需改写为：

```vue
<!-- 兼容模式下 -->
<w-input v-model:model-value="value" />
```

## 兼容性

| 版本    | Chrome | Edge  | Firefox | Safari  |
| ------- | ------ | ----- | ------- | ------- |
| 0.0.7 + | >= 85  | >= 85 | >= 79   | >= 14.1 |

> Vue 3 不支持 IE11，WinDesign Next 同样不支持。

## 本地开发

### 分支规范

| 分支     | 用途                         |
| -------- | ---------------------------- |
| `master` | 日常开发统一提交分支         |
| `rc`     | 发版统一分支，由 master 合入 |

> 所有开发提交请推送到 `master` 分支，发版时由维护人员合入 `rc` 分支进行发布。

### 开发步骤

```bash
# 1. 克隆仓库
git clone http://tfs2018-web.winning.com.cn:8080/tfs/WinCode/WOP/_git/win-design-next

# 2. 安装依赖
pnpm install --registry=http://172.16.9.57:8081/repository/npm-group/

# 3. 启动文档站
pnpm run docs:dev

# 4. 构建
pnpm run build

# 5. 运行测试
pnpm run test

# 6. 类型检查
pnpm run typecheck
```

常用脚本：

| 命令                 | 说明                 |
| -------------------- | -------------------- |
| `pnpm run docs:dev`  | 启动文档站           |
| `pnpm run build`     | 构建全部组件包       |
| `pnpm run test`      | 运行单元测试         |
| `pnpm run lint`      | 代码规范检查         |
| `pnpm run lint:fix`  | 自动修复代码规范问题 |
| `pnpm run format`    | Prettier 格式化      |
| `pnpm run typecheck` | TypeScript 类型检查  |
| `pnpm run gen`       | 新建组件脚手架       |

## 常见问题

### 1. 安装时找不到包？

确认 npm registry 已指向公司内部仓库：

```bash
npm config get registry
# 应为 http://172.16.9.57:8081/repository/npm-group/
```

### 2. 组件样式没有生效？

确保引入了 CSS 文件：

```ts
import 'win-design-next/dist/index.css'
```

### 3. 按需引入时样式丢失？

配合自动导入插件使用，或手动引入对应组件的样式文件：

```ts
import 'win-design-next/es/components/button/style/css'
```

### 4. Volar 类型提示不生效？

检查 `tsconfig.json` 是否配置了 `"types": ["win-design-next/global"]`，并重启 IDE。

## 相关链接

- **文档站**: http://wued.winning-health.com.cn:8088/win-design-next/
- **代码仓库**: http://tfs2018-web.winning.com.cn:8080/tfs/WinCode/WOP/_git/win-design-next

## 联系我们

如有问题、意见或需求，请通过钉钉或企业微信加入 WinDesign 交流群，或者联系维护人员（向娇娇）获取帮助。
