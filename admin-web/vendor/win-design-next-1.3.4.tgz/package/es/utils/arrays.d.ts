export declare const unique: <T>(arr: T[]) => T[];
export declare const extractFirst: <T>(arr: T | T[]) => T;
type Many<T> = T | ReadonlyArray<T>;
/** like `_.castArray`, except falsy value returns empty array. */
export declare const castArray: <T>(arr: Many<T>) => T[];
export { castArray as ensureArray } from 'lodash-es';
export declare const flattenDeep: <T>(array: any[]) => T[];
export declare const flatten: <T>(array: T[][]) => T[];
export declare const flatMap: <T, U>(array: T[], iteratee: (value: T, index: number, array: T[]) => U | U[]) => U[];
export declare const union: <T>(...arrays: Array<T[] | undefined>) => T[];
