export declare const COMPONENT_NAME = "WDescriptionsItem";
