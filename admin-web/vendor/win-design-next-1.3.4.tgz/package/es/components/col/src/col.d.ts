import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
import type Col from './col.vue';
export type ColSizeObject = {
    span?: number | string;
    offset?: number | string;
    pull?: number | string;
    push?: number | string;
};
export type ColSize = number | string | ColSizeObject;
export declare const colProps: {
    readonly tag: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
    readonly span: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 24, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly pull: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly push: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly xs: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize) | ((new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly sm: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize) | ((new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly md: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize) | ((new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly lg: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize) | ((new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly xl: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize) | ((new (...args: any[]) => string | number | ColSizeObject) | (() => ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
};
export type ColProps = ExtractPropTypes<typeof colProps>;
export type ColPropsPublic = ExtractPublicPropTypes<typeof colProps>;
export type ColInstance = InstanceType<typeof Col> & unknown;
