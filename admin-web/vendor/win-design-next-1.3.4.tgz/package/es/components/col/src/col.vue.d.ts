declare var __VLS_7: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_7) => any;
};
declare const __VLS_base: import("vue").DefineComponent<{
    readonly tag: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
    readonly span: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 24, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly pull: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly push: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly xs: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly sm: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly md: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly lg: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly xl: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly tag: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
    readonly span: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 24, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly pull: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly push: import("win-design-next/es/utils").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, 0, boolean>;
    readonly xs: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly sm: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly md: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly lg: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
    readonly xl: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown, () => import("win-design-next/es/utils").Mutable<{}>, boolean>;
}>>, {
    readonly span: import("win-design-next/es/utils").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly push: import("win-design-next/es/utils").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly offset: import("win-design-next/es/utils").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly tag: string;
    readonly pull: import("win-design-next/es/utils").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly xs: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown>;
    readonly sm: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown>;
    readonly md: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown>;
    readonly lg: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown>;
    readonly xl: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize) | ((new (...args: any[]) => string | number | import("./col").ColSizeObject) | (() => import("./col").ColSize))[], unknown, unknown>;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
