import 'win-design-next/es/components/base/style/css';
import 'win-design-next/es/components/input/style/css';
import 'win-design-next/es/components/tag/style/css';
import 'win-design-next/es/components/scrollbar/style/css';
import 'win-design-next/es/components/popper/style/css';
import 'win-design-next/theme-chalk/w-table-select.css';
