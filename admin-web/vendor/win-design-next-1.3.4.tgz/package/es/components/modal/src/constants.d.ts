import type { CSSProperties, ComputedRef, InjectionKey, Ref } from 'vue';
import type { UseNamespaceReturn } from 'win-design-next/es/hooks';
export type ModalContext = {
    modalRef: Ref<HTMLElement | undefined>;
    headerRef: Ref<HTMLElement | undefined>;
    bodyId: Ref<string>;
    ns: UseNamespaceReturn;
    rendered: Ref<boolean>;
    style: ComputedRef<CSSProperties>;
    resizeL: Ref<HTMLElement | undefined>;
    resizeR: Ref<HTMLElement | undefined>;
    resizeB: Ref<HTMLElement | undefined>;
    resizeBR: Ref<HTMLElement | undefined>;
    resizeLB: Ref<HTMLElement | undefined>;
};
export declare const modalInjectionKey: InjectionKey<ModalContext>;
export declare const DEFAULT_MODAL_TRANSITION = "dialog-fade";
