import type CheckTag from './check-tag.vue';
import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
export declare const checkTagProps: {
    readonly checked: BooleanConstructor;
    readonly disabled: BooleanConstructor;
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "primary", boolean>;
};
export type CheckTagProps = ExtractPropTypes<typeof checkTagProps>;
export type CheckTagPropsPublic = ExtractPublicPropTypes<typeof checkTagProps>;
export declare const checkTagEmits: {
    'update:checked': (value: boolean) => boolean;
    change: (value: boolean) => boolean;
};
export type CheckTagEmits = typeof checkTagEmits;
export type CheckTagInstance = InstanceType<typeof CheckTag> & unknown;
