declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_base: import("vue").DefineComponent<{
    readonly checked: BooleanConstructor;
    readonly disabled: BooleanConstructor;
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "primary", boolean>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (value: boolean) => void;
    "update:checked": (value: boolean) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly checked: BooleanConstructor;
    readonly disabled: BooleanConstructor;
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "primary", boolean>;
}>> & {
    onChange?: ((value: boolean) => any) | undefined;
    "onUpdate:checked"?: ((value: boolean) => any) | undefined;
}, {
    readonly disabled: boolean;
    readonly type: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>;
    readonly checked: boolean;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
