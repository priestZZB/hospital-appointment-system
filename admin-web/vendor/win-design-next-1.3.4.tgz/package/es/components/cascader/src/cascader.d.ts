import type { CascaderNode, CascaderValue } from 'win-design-next/es/components/cascader-panel';
import type { Placement, PopperEffect } from 'win-design-next/es/components/popper';
export declare const cascaderProps: {
    emptyValues: ArrayConstructor;
    valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    placeholder: StringConstructor;
    disabled: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    clearable: BooleanConstructor;
    clearIcon: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}, {}>, boolean>;
    filterable: BooleanConstructor;
    filterMethod: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, (node: CascaderNode, keyword: string) => boolean, boolean>;
    separator: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    showAllLevels: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    collapseTags: BooleanConstructor;
    maxCollapseTags: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    collapseTagsTooltip: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    maxCollapseTagsTooltipHeight: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(NumberConstructor | StringConstructor)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    debounce: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    beforeFilter: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, () => true, boolean>;
    placement: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => Placement))[], Placement, unknown, string, boolean>;
    fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Placement[]) | (() => Placement[]) | ((new (...args: any[]) => Placement[]) | (() => Placement[]))[], unknown, unknown, string[], boolean>;
    popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, undefined, boolean>;
    teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => PopperEffect) | ((new (...args: any[]) => string) | (() => PopperEffect))[], unknown, unknown, string, boolean>;
    tagType: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    tagEffect: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    validateEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    persistent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    checkAll: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCheckedStrategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
    checkOnClickNode: BooleanConstructor;
    showPrefix: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modelValue: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null) | ((new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    options: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderOption[], boolean>;
    props: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderProps, boolean>;
};
export declare const cascaderEmits: {
    "update:modelValue": (value: CascaderValue | null | undefined) => boolean;
    change: (value: CascaderValue | null | undefined) => boolean;
    focus: (evt: FocusEvent) => boolean;
    blur: (evt: FocusEvent) => boolean;
    clear: () => boolean;
    visibleChange: (val: boolean) => boolean;
    expandChange: (val: CascaderValue) => boolean;
    removeTag: (val: CascaderNode["valueByOption"]) => boolean;
};
export type CascaderEmits = typeof cascaderEmits;
