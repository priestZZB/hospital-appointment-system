import type { ComputedRef, StyleValue } from 'vue';
import type { CascaderNode, CascaderPanelInstance, CascaderValue } from 'win-design-next/es/components/cascader-panel';
declare const __VLS_base: import("vue").DefineComponent<{
    emptyValues: ArrayConstructor;
    valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    placeholder: StringConstructor;
    disabled: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    clearable: BooleanConstructor;
    clearIcon: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}, {}>, boolean>;
    filterable: BooleanConstructor;
    filterMethod: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, (node: CascaderNode, keyword: string) => boolean, boolean>;
    separator: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    showAllLevels: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    collapseTags: BooleanConstructor;
    maxCollapseTags: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    collapseTagsTooltip: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    maxCollapseTagsTooltipHeight: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(NumberConstructor | StringConstructor)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    debounce: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    beforeFilter: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, () => true, boolean>;
    placement: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement))[], import("win-design-next/es/components/popper").Placement, unknown, string, boolean>;
    fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]) | ((new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]))[], unknown, unknown, string[], boolean>;
    popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect) | ((new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect))[], unknown, unknown, string, boolean>;
    tagType: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    tagEffect: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    validateEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    persistent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    checkAll: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCheckedStrategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
    checkOnClickNode: BooleanConstructor;
    showPrefix: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modelValue: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null) | ((new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    options: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderOption[], boolean>;
    props: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderProps, boolean>;
}, {
    /**
     * @description get an array of currently selected node,(leafOnly) whether only return the leaf checked nodes, default is `false`
     */
    getCheckedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
    /**
     * @description cascader panel ref
     */
    cascaderPanelRef: import("vue").Ref<CascaderPanelInstance | undefined>;
    /**
     * @description toggle the visible of popper
     */
    togglePopperVisible: (visible?: boolean) => void;
    /**
     * @description cascader content ref
     */
    contentRef: ComputedRef<HTMLElement | undefined>;
    /**
     * @description selected content text
     */
    presentText: ComputedRef<string>;
    /** @description focus the input element */
    focus: () => void;
    /** @description blur the input element */
    blur: () => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    focus: (evt: FocusEvent) => void;
    "update:modelValue": (value: CascaderValue | null | undefined) => void;
    change: (value: CascaderValue | null | undefined) => void;
    clear: () => void;
    blur: (evt: FocusEvent) => void;
    visibleChange: (val: boolean) => void;
    expandChange: (val: CascaderValue) => void;
    removeTag: (val: import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    emptyValues: ArrayConstructor;
    valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    placeholder: StringConstructor;
    disabled: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    clearable: BooleanConstructor;
    clearIcon: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}, {}>, boolean>;
    filterable: BooleanConstructor;
    filterMethod: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (node: CascaderNode, keyword: string) => boolean) | (() => (node: CascaderNode, keyword: string) => boolean) | {
        (): (node: CascaderNode, keyword: string) => boolean;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, (node: CascaderNode, keyword: string) => boolean, boolean>;
    separator: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    showAllLevels: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    collapseTags: BooleanConstructor;
    maxCollapseTags: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    collapseTagsTooltip: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    maxCollapseTagsTooltipHeight: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(NumberConstructor | StringConstructor)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    debounce: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    beforeFilter: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => (value: string) => boolean | Promise<any>) | (() => (value: string) => boolean | Promise<any>) | {
        (): (value: string) => boolean | Promise<any>;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, () => true, boolean>;
    placement: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement))[], import("win-design-next/es/components/popper").Placement, unknown, string, boolean>;
    fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]) | ((new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]))[], unknown, unknown, string[], boolean>;
    popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect) | ((new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect))[], unknown, unknown, string, boolean>;
    tagType: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    tagEffect: {
        default: string;
        type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    validateEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    persistent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    checkAll: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCheckedStrategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
    checkOnClickNode: BooleanConstructor;
    showPrefix: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modelValue: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null) | ((new (...args: any[]) => string | number | Record<string, any> | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue | (import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue)[]) | (() => CascaderValue | null))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    options: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderOption[]) | (() => import("win-design-next/es/components/cascader-panel").CascaderOption[]))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderOption[], boolean>;
    props: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps) | ((new (...args: any[]) => import("win-design-next/es/components/cascader-panel").CascaderProps) | (() => import("win-design-next/es/components/cascader-panel").CascaderProps))[], unknown, unknown, () => import("win-design-next/es/components/cascader-panel").CascaderProps, boolean>;
}>> & {
    "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
    onFocus?: ((evt: FocusEvent) => any) | undefined;
    onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
    onBlur?: ((evt: FocusEvent) => any) | undefined;
    onClear?: (() => any) | undefined;
    onVisibleChange?: ((val: boolean) => any) | undefined;
    onExpandChange?: ((val: CascaderValue) => any) | undefined;
    onRemoveTag?: ((val: import("win-design-next/es/components/cascader-panel").CascaderNodeValue | import("win-design-next/es/components/cascader-panel").CascaderNodePathValue) => any) | undefined;
}, {
    disabled: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    separator: string;
    props: import("win-design-next/es/components/cascader-panel").CascaderProps;
    placement: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("win-design-next/es/components/popper").Placement))[], import("win-design-next/es/components/popper").Placement, unknown>;
    options: import("win-design-next/es/components/cascader-panel").CascaderOption[];
    effect: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect) | ((new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect))[], unknown, unknown>;
    valueOnClear: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown>;
    fallbackPlacements: import("win-design-next/es/components/popper").Placement[];
    popperClass: import("win-design-next/es/utils").ClassValue;
    popperStyle: StyleValue;
    persistent: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    teleported: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    clearIcon: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
    validateEvent: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    clearable: boolean;
    debounce: number;
    filterMethod: (node: CascaderNode, keyword: string) => boolean;
    filterable: boolean;
    checkOnClickNode: boolean;
    showPrefix: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    checkAll: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showAllLevels: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapseTags: boolean;
    maxCollapseTags: number;
    collapseTagsTooltip: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    beforeFilter: (value: string) => boolean | Promise<any>;
    tagType: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>;
    tagEffect: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
    showCheckedStrategy: string;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
