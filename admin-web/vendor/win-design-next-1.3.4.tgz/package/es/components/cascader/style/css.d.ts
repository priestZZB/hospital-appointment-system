import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-cascader.css';
import 'win-design-next/es/components/input/style/css';
import 'win-design-next/es/components/popper/style/css';
import 'win-design-next/es/components/tag/style/css';
import 'win-design-next/es/components/cascader-panel/style/css';
