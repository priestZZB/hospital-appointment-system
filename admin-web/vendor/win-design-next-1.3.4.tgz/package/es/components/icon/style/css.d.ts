import 'win-design-next/es/components/base/style/css';
