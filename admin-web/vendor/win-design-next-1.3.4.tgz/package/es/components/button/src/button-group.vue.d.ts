declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_base: import("vue").DefineComponent<{
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "", boolean>;
    readonly smart: BooleanConstructor;
    readonly smartLink: BooleanConstructor;
    readonly smartType: {
        readonly type: StringConstructor;
        readonly default: "";
    };
    readonly position: {
        readonly type: StringConstructor;
        readonly default: "left";
    };
    readonly gap: {
        readonly type: NumberConstructor;
        readonly default: 8;
    };
    readonly discrete: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "", boolean>;
    readonly smart: BooleanConstructor;
    readonly smartLink: BooleanConstructor;
    readonly smartType: {
        readonly type: StringConstructor;
        readonly default: "";
    };
    readonly position: {
        readonly type: StringConstructor;
        readonly default: "left";
    };
    readonly gap: {
        readonly type: NumberConstructor;
        readonly default: 8;
    };
    readonly discrete: BooleanConstructor;
}>>, {
    readonly position: string;
    readonly gap: number;
    readonly type: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "error" | "success" | "warning" | "info" | "primary" | "danger", unknown>;
    readonly discrete: boolean;
    readonly smart: boolean;
    readonly smartLink: boolean;
    readonly smartType: string;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
