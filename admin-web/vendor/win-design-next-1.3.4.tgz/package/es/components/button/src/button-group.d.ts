import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
export declare const buttonGroupProps: {
    /**
     * @description control the size of buttons in this button-group
     */
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    /**
     * @description control the type of buttons in this button-group
     */
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "", boolean>;
    readonly smart: BooleanConstructor;
    readonly smartLink: BooleanConstructor;
    readonly smartType: {
        readonly type: StringConstructor;
        readonly default: "";
    };
    readonly position: {
        readonly type: StringConstructor;
        readonly default: "left";
    };
    readonly gap: {
        readonly type: NumberConstructor;
        readonly default: 8;
    };
    readonly discrete: BooleanConstructor;
};
export type ButtonGroupProps = ExtractPropTypes<typeof buttonGroupProps>;
export type ButtonGroupPropsPublic = ExtractPublicPropTypes<typeof buttonGroupProps>;
