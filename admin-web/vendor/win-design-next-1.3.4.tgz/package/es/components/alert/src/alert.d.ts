import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
export declare const alertEffects: readonly ["light", "dark"];
export declare const alertProps: {
    readonly showAfter: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly hideAfter: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 200, boolean>;
    readonly autoClose: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly title: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly description: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly type: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "error" | "success" | "warning" | "info" | "primary" | "danger", unknown, "primary", boolean>;
    readonly closable: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly closeText: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showIcon: BooleanConstructor;
    readonly center: BooleanConstructor;
    readonly effect: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "dark" | "light", unknown, "light", boolean>;
};
export type AlertProps = ExtractPropTypes<typeof alertProps>;
export type AlertPropsPublic = ExtractPublicPropTypes<typeof alertProps>;
export declare const alertEmits: {
    open: () => boolean;
    close: (evt?: Event) => boolean;
};
export type AlertEmits = typeof alertEmits;
