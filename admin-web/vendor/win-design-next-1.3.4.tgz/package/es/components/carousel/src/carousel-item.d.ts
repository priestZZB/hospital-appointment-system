import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
export declare const carouselItemProps: {
    readonly name: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly label: import("win-design-next/es/utils").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
};
export type CarouselItemProps = ExtractPropTypes<typeof carouselItemProps>;
export type CarouselItemPropsPublic = ExtractPublicPropTypes<typeof carouselItemProps>;
