import type { InjectionKey, Ref } from 'vue';
import type { CommonPickerContext } from './composables/use-common-picker';
export { COMMIT_TRIGGER_DRAFT_INJECTION_KEY, HAS_COMMIT_TRIGGER_DRAFT_INJECTION_KEY, } from 'win-design-next/es/components/time-picker/src/constants';
/**
 * Pro 触发器在 CommonPickerContext 基础上自持 focusType（经典版 useCommonPicker
 * 已不再提供），经 ROOT_COMMON_PICKER_INJECTION_KEY 下发给面板
 */
export type ProCommonPickerContext = CommonPickerContext & {
    focusType: Ref<'start' | 'end'>;
};
export declare const timeUnits: readonly ["hours", "minutes", "seconds"];
/** 范围面板 Tab 切换中，禁止 focusType watch 抢输入框焦点（字符串 key 避免 HMR 多实例 Symbol 不一致） */
export declare const RANGE_PANEL_TAB_FOCUS_KEY = "WN_RANGE_PANEL_TAB_FOCUS";
/** 触发器开始框手动录满、尚未点选面板时的开始日期草稿（供面板启用结束 Tab） */
export declare const RANGE_PARTIAL_START_KEY = "WN_RANGE_PARTIAL_START";
export declare const PICKER_BASE_INJECTION_KEY = "WN_PICKER_BASE";
export declare const PICKER_POPPER_OPTIONS_INJECTION_KEY = "WPopperOptions";
export declare const ROOT_COMMON_PICKER_INJECTION_KEY: InjectionKey<ProCommonPickerContext>;
export type { CommonPickerContext };
export declare const DEFAULT_FORMATS_TIME = "HH:mm:ss";
export declare const DEFAULT_FORMATS_DATE = "YYYY-MM-DD";
/** 仅面板点选、触发器只读，不启用块级智能录入（与 OpenSpec 一致） */
export declare const MANUAL_INPUT_DISABLED_PICKER_TYPES: readonly ["week", "dates", "months", "years", "quarters", "quarter", "quarterrange"];
export declare function isManualInputDisabledPickerType(type: string): boolean;
export declare const DEFAULT_FORMATS_DATEPICKER: {
    date: string;
    dates: string;
    week: string;
    year: string;
    years: string;
    month: string;
    months: string;
    quarter: string;
    quarters: string;
    datetime: string;
    monthrange: string;
    yearrange: string;
    quarterrange: string;
    daterange: string;
    datetimerange: string;
};
export type TimeUnit = typeof timeUnits[number];
