declare const __VLS_export: import("vue").DefineComponent<{
    readonly disabledHours: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledHours>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly disabledMinutes: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledMinutes>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly disabledSeconds: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledSeconds>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly role: {
        readonly type: import("vue").PropType<string>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly spinnerDate: {
        readonly type: import("vue").PropType<import("dayjs").Dayjs>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly showSeconds: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly arrowControl: BooleanConstructor;
    readonly amPmMode: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A") | ((new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A"))[], unknown, unknown, "", boolean>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (...args: any[]) => void;
    "select-range": (...args: any[]) => void;
    "set-option": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly disabledHours: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledHours>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly disabledMinutes: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledMinutes>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly disabledSeconds: {
        readonly type: import("vue").PropType<import("win-design-next").GetDisabledSeconds>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly role: {
        readonly type: import("vue").PropType<string>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly spinnerDate: {
        readonly type: import("vue").PropType<import("dayjs").Dayjs>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly showSeconds: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly arrowControl: BooleanConstructor;
    readonly amPmMode: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A") | ((new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A"))[], unknown, unknown, "", boolean>;
}>> & {
    onChange?: ((...args: any[]) => any) | undefined;
    "onSelect-range"?: ((...args: any[]) => any) | undefined;
    "onSet-option"?: ((...args: any[]) => any) | undefined;
}, {
    readonly arrowControl: boolean;
    readonly showSeconds: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly amPmMode: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A") | ((new (...args: any[]) => "" | "a" | "A") | (() => "" | "a" | "A"))[], unknown, unknown>;
}, {}>;
declare const _default: typeof __VLS_export;
export default _default;
