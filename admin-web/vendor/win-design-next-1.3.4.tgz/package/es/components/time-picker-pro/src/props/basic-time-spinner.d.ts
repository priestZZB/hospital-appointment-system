export { type BasicTimeSpinnerProps, type BasicTimeSpinnerPropsPublic, basicTimeSpinnerProps, } from 'win-design-next/es/components/time-picker/src/props/basic-time-spinner';
