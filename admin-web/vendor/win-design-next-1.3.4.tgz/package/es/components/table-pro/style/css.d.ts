import 'win-design-next/es/components/base/style/css';
import 'win-design-next/es/components/table/style/css';
import 'win-design-next/es/components/checkbox/style/css';
import 'win-design-next/es/components/radio/style/css';
import 'win-design-next/es/components/icon/style/css';
import 'win-design-next/theme-chalk/w-table-pro.css';
