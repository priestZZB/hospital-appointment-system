import type { ClassValue } from 'win-design-next/es/utils';
import type { PopperEffect } from './popper';
import type { ExtractPublicPropTypes, StyleValue } from 'vue';
import type { Options, Placement } from '@popperjs/core';
import type { Measurable } from './constants';
import type Content from './content.vue';
import type { PopperArrowProps } from './arrow';
declare const POSITIONING_STRATEGIES: readonly ["fixed", "absolute"];
export interface CreatePopperInstanceParams {
    referenceEl: Measurable;
    popperContentEl: HTMLElement;
    arrowEl: HTMLElement | undefined;
}
export interface PopperCoreConfigProps {
    boundariesPadding?: number;
    fallbackPlacements?: Placement[];
    gpuAcceleration?: boolean;
    /**
     * @description offset of the Tooltip
     */
    offset?: number;
    /**
     * @description position of Tooltip
     */
    placement?: Placement;
    /**
     * @description [popper.js](https://popper.js.org/docs/v2/) parameters
     */
    popperOptions?: Partial<Options>;
    strategy?: typeof POSITIONING_STRATEGIES[number];
}
/**
 * @deprecated Removed after 3.0.0, Use `PopperCoreConfigProps` instead.
 */
export declare const popperCoreConfigProps: {
    readonly boundariesPadding: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Placement[]) | (() => Placement[]) | ((new (...args: any[]) => Placement[]) | (() => Placement[]))[], unknown, unknown, undefined, boolean>;
    readonly gpuAcceleration: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 12, boolean>;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, Placement, unknown, "bottom", boolean>;
    readonly popperOptions: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], unknown, unknown, () => {}, boolean>;
    readonly strategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "fixed" | "absolute", unknown, "absolute", boolean>;
};
/**
 * @deprecated Removed after 3.0.0, Use `PopperCoreConfigProps` instead.
 */
export type PopperCoreConfigPropsPublic = ExtractPublicPropTypes<typeof popperCoreConfigProps>;
export interface PopperContentProps extends PopperCoreConfigProps, PopperArrowProps {
    id?: string;
    style?: StyleValue;
    className?: ClassValue;
    effect?: PopperEffect;
    visible?: boolean;
    enterable?: boolean;
    pure?: boolean;
    focusOnShow?: boolean;
    trapping?: boolean;
    popperClass?: ClassValue;
    popperStyle?: StyleValue;
    referenceEl?: HTMLElement;
    triggerTargetEl?: HTMLElement;
    stopPopperMouseEvent?: boolean;
    virtualTriggering?: boolean;
    zIndex?: number;
    ariaLabel?: string;
    loop?: boolean;
}
/**
 * @deprecated Removed after 3.0.0, Use `PopperContentProps` instead.
 */
export declare const popperContentProps: {
    readonly loop: BooleanConstructor;
    readonly ariaLabel: StringConstructor;
    readonly id: StringConstructor;
    readonly style: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly className: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => PopperEffect) | ((new (...args: any[]) => string) | (() => PopperEffect))[], unknown, unknown, "lighter", boolean>;
    readonly visible: BooleanConstructor;
    readonly enterable: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pure: BooleanConstructor;
    readonly focusOnShow: BooleanConstructor;
    readonly trapping: BooleanConstructor;
    readonly popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly referenceEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly triggerTargetEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly stopPopperMouseEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly virtualTriggering: BooleanConstructor;
    readonly zIndex: NumberConstructor;
    readonly arrowOffset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 5, boolean>;
    readonly boundariesPadding: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Placement[]) | (() => Placement[]) | ((new (...args: any[]) => Placement[]) | (() => Placement[]))[], unknown, unknown, undefined, boolean>;
    readonly gpuAcceleration: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 12, boolean>;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, Placement, unknown, "bottom", boolean>;
    readonly popperOptions: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], unknown, unknown, () => {}, boolean>;
    readonly strategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "fixed" | "absolute", unknown, "absolute", boolean>;
};
/**
 * @deprecated Removed after 3.0.0, Use `PopperContentProps` instead.
 */
export type PopperContentPropsPublic = ExtractPublicPropTypes<typeof popperContentProps>;
export declare const popperCoreConfigPropsDefaults: {
    readonly boundariesPadding: 0;
    readonly gpuAcceleration: true;
    readonly offset: 12;
    readonly placement: "bottom";
    readonly popperOptions: () => {};
    readonly strategy: "absolute";
};
export declare const popperContentPropsDefaults: {
    readonly effect: "lighter";
    readonly enterable: true;
    readonly stopPopperMouseEvent: true;
    readonly visible: false;
    readonly pure: false;
    readonly focusOnShow: false;
    readonly trapping: false;
    readonly virtualTriggering: false;
    readonly loop: false;
    readonly style: undefined;
    readonly popperStyle: undefined;
    readonly popperClass: undefined;
    readonly arrowOffset: 5;
    readonly boundariesPadding: 0;
    readonly gpuAcceleration: true;
    readonly offset: 12;
    readonly placement: "bottom";
    readonly popperOptions: () => {};
    readonly strategy: "absolute";
};
export declare const popperContentEmits: {
    mouseenter: (evt: MouseEvent) => boolean;
    mouseleave: (evt: MouseEvent) => boolean;
    focus: () => boolean;
    blur: () => boolean;
    close: () => boolean;
};
export type PopperContentEmits = typeof popperContentEmits;
export type PopperContentInstance = InstanceType<typeof Content> & unknown;
/** @deprecated use `popperCoreConfigProps` instead, and it will be deprecated in the next major version */
export declare const usePopperCoreConfigProps: {
    readonly boundariesPadding: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Placement[]) | (() => Placement[]) | ((new (...args: any[]) => Placement[]) | (() => Placement[]))[], unknown, unknown, undefined, boolean>;
    readonly gpuAcceleration: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 12, boolean>;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, Placement, unknown, "bottom", boolean>;
    readonly popperOptions: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], unknown, unknown, () => {}, boolean>;
    readonly strategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "fixed" | "absolute", unknown, "absolute", boolean>;
};
/** @deprecated use `popperContentProps` instead, and it will be deprecated in the next major version */
export declare const usePopperContentProps: {
    readonly loop: BooleanConstructor;
    readonly ariaLabel: StringConstructor;
    readonly id: StringConstructor;
    readonly style: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly className: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => PopperEffect) | ((new (...args: any[]) => string) | (() => PopperEffect))[], unknown, unknown, "lighter", boolean>;
    readonly visible: BooleanConstructor;
    readonly enterable: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pure: BooleanConstructor;
    readonly focusOnShow: BooleanConstructor;
    readonly trapping: BooleanConstructor;
    readonly popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly referenceEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly triggerTargetEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly stopPopperMouseEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly virtualTriggering: BooleanConstructor;
    readonly zIndex: NumberConstructor;
    readonly arrowOffset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 5, boolean>;
    readonly boundariesPadding: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Placement[]) | (() => Placement[]) | ((new (...args: any[]) => Placement[]) | (() => Placement[]))[], unknown, unknown, undefined, boolean>;
    readonly gpuAcceleration: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 12, boolean>;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, Placement, unknown, "bottom", boolean>;
    readonly popperOptions: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], unknown, unknown, () => {}, boolean>;
    readonly strategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "fixed" | "absolute", unknown, "absolute", boolean>;
};
/** @deprecated use `popperContentEmits` instead, and it will be deprecated in the next major version */
export declare const usePopperContentEmits: {
    mouseenter: (evt: MouseEvent) => boolean;
    mouseleave: (evt: MouseEvent) => boolean;
    focus: () => boolean;
    blur: () => boolean;
    close: () => boolean;
};
/** @deprecated use `PopperCoreConfigProps` instead, and it will be deprecated in the next major version */
export type UsePopperCoreConfigProps = PopperCoreConfigProps;
/** @deprecated use `PopperContentProps` instead, and it will be deprecated in the next major version */
export type UsePopperContentProps = PopperContentProps;
/** @deprecated use `PopperContentInstance` instead, and it will be deprecated in the next major version */
export type WPopperArrowContent = PopperContentInstance;
export {};
