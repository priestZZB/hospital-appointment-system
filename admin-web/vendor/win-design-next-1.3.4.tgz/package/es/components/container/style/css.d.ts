import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-container.css';
import 'win-design-next/theme-chalk/w-aside.css';
import 'win-design-next/theme-chalk/w-footer.css';
import 'win-design-next/theme-chalk/w-header.css';
import 'win-design-next/theme-chalk/w-main.css';
