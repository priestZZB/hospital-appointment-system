import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
import type { Language } from 'win-design-next/es/locale';
import type { ButtonConfigContext } from 'win-design-next/es/components/button';
import type { CardConfigContext } from 'win-design-next/es/components/card';
import type { DialogConfigContext } from 'win-design-next/es/components/dialog';
import type { MessageConfigContext } from 'win-design-next/es/components/message';
import type { LinkConfigContext } from 'win-design-next/es/components/link';
import type { TableConfigContext } from 'win-design-next/es/components/table';
export type ExperimentalFeatures = {};
export declare const themeTypes: readonly ["", "sauce-purple", "maternity-pink", "innovation-green", "calendula"];
export declare const fontSizeBaseTypes: readonly ["", "14px", "16px", "18px"];
export declare const configProviderProps: {
    readonly emptyValues: ArrayConstructor;
    readonly valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    readonly a11y: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly locale: {
        readonly type: import("vue").PropType<Language>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly button: {
        readonly type: import("vue").PropType<ButtonConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly card: {
        readonly type: import("vue").PropType<CardConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly dialog: {
        readonly type: import("vue").PropType<DialogConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly link: {
        readonly type: import("vue").PropType<LinkConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly experimentalFeatures: {
        readonly type: import("vue").PropType<ExperimentalFeatures>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly keyboardNavigation: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly message: {
        readonly type: import("vue").PropType<MessageConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly zIndex: NumberConstructor;
    readonly namespace: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "w3", boolean>;
    readonly table: {
        readonly type: import("vue").PropType<TableConfigContext>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly theme: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "" | "sauce-purple" | "maternity-pink" | "innovation-green" | "calendula", unknown, "", boolean>;
    readonly fontSizeBase: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "" | "14px" | "16px" | "18px", unknown, "14px", boolean>;
};
export type ConfigProviderProps = ExtractPropTypes<typeof configProviderProps>;
export type ConfigProviderPropsPublic = ExtractPublicPropTypes<typeof configProviderProps>;
