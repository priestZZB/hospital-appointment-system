declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_base: import("vue").DefineComponent<{
    readonly zIndex: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined) | ((new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined))[], unknown, unknown, 100, boolean>;
    readonly target: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly position: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "top" | "bottom", unknown, "top", boolean>;
}, {
    /** @description update affix status */
    update: () => void;
    /** @description update rootRect info */
    updateRoot: () => Promise<void>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (fixed: boolean) => void;
    scroll: (args_0: {
        scrollTop: number;
        fixed: boolean;
    }) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly zIndex: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined) | ((new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined))[], unknown, unknown, 100, boolean>;
    readonly target: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly position: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "top" | "bottom", unknown, "top", boolean>;
}>> & {
    onChange?: ((fixed: boolean) => any) | undefined;
    onScroll?: ((args_0: {
        scrollTop: number;
        fixed: boolean;
    }) => any) | undefined;
}, {
    readonly position: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "top" | "bottom", unknown>;
    readonly zIndex: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined) | ((new (...args: any[]) => string | number) | (() => import("csstype").Property.ZIndex | undefined))[], unknown, unknown>;
    readonly offset: number;
    readonly target: string;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
