import Color from 'win-design-next/es/components/color-picker-panel/src/utils/color';
declare function show(): void;
declare function hide(): void;
declare function focus(): void;
declare function blur(): void;
declare const __VLS_export: import("vue").DefineComponent<{
    readonly ariaLabel: StringConstructor;
    readonly emptyValues: ArrayConstructor;
    readonly valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    readonly persistent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly modelValue: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => string | null) | ((new (...args: any[]) => string) | (() => string | null))[], unknown, unknown, undefined, boolean>;
    readonly id: StringConstructor;
    readonly showAlpha: BooleanConstructor;
    readonly colorFormat: StringConstructor;
    readonly disabled: BooleanConstructor;
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly tabindex: import("win-design-next/es/utils").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
    readonly teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly appendTo: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | ((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly predefine: {
        readonly type: import("vue").PropType<string[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly validateEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}, {
    /**
     * @description current color object
     */
    color: Color;
    /**
     * @description manually show ColorPicker
     */
    show: typeof show;
    /**
     * @description manually hide ColorPicker
     */
    hide: typeof hide;
    /**
     * @description focus the input element
     */
    focus: typeof focus;
    /**
     * @description blur the input element
     */
    blur: typeof blur;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    focus: (evt: FocusEvent) => void;
    "update:modelValue": (val: string | null) => void;
    change: (val: string | null) => void;
    blur: (evt: FocusEvent) => void;
    activeChange: (val: string | null) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly ariaLabel: StringConstructor;
    readonly emptyValues: ArrayConstructor;
    readonly valueOnClear: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown, undefined, boolean>;
    readonly persistent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly modelValue: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => string | null) | ((new (...args: any[]) => string) | (() => string | null))[], unknown, unknown, undefined, boolean>;
    readonly id: StringConstructor;
    readonly showAlpha: BooleanConstructor;
    readonly colorFormat: StringConstructor;
    readonly disabled: BooleanConstructor;
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly tabindex: import("win-design-next/es/utils").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
    readonly teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly appendTo: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | ((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly predefine: {
        readonly type: import("vue").PropType<string[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly validateEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>> & {
    "onUpdate:modelValue"?: ((val: string | null) => any) | undefined;
    onFocus?: ((evt: FocusEvent) => any) | undefined;
    onChange?: ((val: string | null) => any) | undefined;
    onBlur?: ((evt: FocusEvent) => any) | undefined;
    onActiveChange?: ((val: string | null) => any) | undefined;
}, {
    readonly disabled: boolean;
    readonly tabindex: import("win-design-next/es/utils").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly modelValue: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | ((new (...args: any[]) => string) | (() => string | null))[], unknown, unknown>;
    readonly valueOnClear: import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null))[], unknown, unknown>;
    readonly popperClass: import("win-design-next/es/utils").ClassValue;
    readonly popperStyle: import("vue").StyleValue;
    readonly persistent: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly teleported: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly validateEvent: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showAlpha: boolean;
}, {}>;
declare const _default: typeof __VLS_export;
export default _default;
