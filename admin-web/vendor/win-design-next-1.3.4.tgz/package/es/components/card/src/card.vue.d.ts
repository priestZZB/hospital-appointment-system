import type { CardProps } from './card';
declare var __VLS_1: {}, __VLS_3: {}, __VLS_5: {};
type __VLS_Slots = {} & {
    header?: (props: typeof __VLS_1) => any;
} & {
    default?: (props: typeof __VLS_3) => any;
} & {
    footer?: (props: typeof __VLS_5) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_WithDefaultsLocal<__VLS_TypePropsToOption<CardProps>, {
    header: string;
    footer: string;
    bodyStyle: string;
    headerClass: undefined;
    bodyClass: undefined;
    footerClass: undefined;
    shadow: undefined;
    interactive: boolean;
}>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<__VLS_WithDefaultsLocal<__VLS_TypePropsToOption<CardProps>, {
    header: string;
    footer: string;
    bodyStyle: string;
    headerClass: undefined;
    bodyClass: undefined;
    footerClass: undefined;
    shadow: undefined;
    interactive: boolean;
}>>>, {
    footer: string;
    header: string;
    bodyStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
    headerClass: string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[] | null;
    bodyClass: string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[] | null;
    footerClass: string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[] | null;
    shadow: "always" | "hover" | "never";
    interactive: boolean;
}, {}>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_TypePropsToOption<T> = {
    [K in keyof T]-?: {} extends Pick<T, K> ? {
        type: import('vue').PropType<Required<T>[K]>;
    } : {
        type: import('vue').PropType<T[K]>;
        required: true;
    };
};
type __VLS_WithDefaultsLocal<P, D> = {
    [K in keyof Pick<P, keyof P>]: K extends keyof D ? __VLS_PrettifyLocal<P[K] & {
        default: D[K];
    }> : P[K];
};
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
type __VLS_PrettifyLocal<T> = {
    [K in keyof T as K]: T[K];
} & {};
