import type { ExtractPublicPropTypes, InjectionKey, StyleValue } from 'vue';
import type { ClassValue } from 'win-design-next/es/utils';
export interface CardProps {
    /**
     * @description title of the card. Also accepts a DOM passed by `slot#header`
     */
    header?: string;
    /**
     * @description content of footer. Also accepts a DOM passed by `slot#footer`
     */
    footer?: string;
    /**
     * @description CSS style of card body
     */
    bodyStyle?: StyleValue;
    /**
     * @description custom class name of card header
     */
    headerClass?: ClassValue;
    /**
     * @description custom class name of card body
     */
    bodyClass?: ClassValue;
    /**
     * @description custom class name of card footer
     */
    footerClass?: ClassValue;
    /**
     * @description when to show card shadows
     */
    shadow?: 'always' | 'hover' | 'never';
    /**
     * @description 是否为可交互式卡片（hover 时上浮）
     */
    interactive?: boolean;
}
/**
 * @deprecated Removed after 3.0.0, Use `CardProps` instead.
 */
export declare const cardProps: {
    readonly header: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly footer: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly bodyStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | StyleValue[]) | (() => StyleValue))[], unknown, unknown, "", boolean>;
    readonly headerClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly bodyClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly footerClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | ClassValue[]) | (() => ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly shadow: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
    readonly interactive: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
};
/**
 * @deprecated Removed after 3.0.0, Use `CardProps` instead.
 */
export type CardPropsPublic = ExtractPublicPropTypes<typeof cardProps>;
export interface CardConfigContext {
    shadow?: CardProps['shadow'];
}
export declare const cardContextKey: InjectionKey<CardConfigContext>;
