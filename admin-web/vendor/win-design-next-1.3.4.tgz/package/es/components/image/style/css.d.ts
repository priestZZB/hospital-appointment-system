import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-image.css';
import 'win-design-next/es/components/image-viewer/style/css';
