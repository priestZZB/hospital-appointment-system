import type { InjectionKey } from 'vue';
import type { CommonPickerContext } from './composables/use-common-picker';
import type { DayOrDays } from './common/props';
export declare const timeUnits: readonly ["hours", "minutes", "seconds"];
export declare const PICKER_BASE_INJECTION_KEY = "WN_PICKER_BASE";
export declare const PICKER_POPPER_OPTIONS_INJECTION_KEY = "WPopperOptions";
export declare const ROOT_COMMON_PICKER_INJECTION_KEY: InjectionKey<CommonPickerContext>;
/**
 * 面板「确定」点击时大输入框未提交草稿的兜底提交通道：
 * 点击 popper 内按钮时 blur 被 isFocusInsideContent 拦截、handleChange 不执行，
 * 面板确认前经此回调提交草稿
 */
export type TriggerDraftCommitResult = DayOrDays | null | undefined;
export declare const COMMIT_TRIGGER_DRAFT_INJECTION_KEY: InjectionKey<() => TriggerDraftCommitResult>;
/**
 * 大输入框是否存在可提交草稿的无副作用探测（供面板确定按钮禁用判断）：
 * 范围面板 minDate/maxDate 未同步草稿时按钮原本恒禁用，点「确定」无效
 */
export declare const HAS_COMMIT_TRIGGER_DRAFT_INJECTION_KEY: InjectionKey<() => boolean>;
export declare const DEFAULT_FORMATS_TIME = "HH:mm:ss";
export declare const DEFAULT_FORMATS_DATE = "YYYY-MM-DD";
/** 仅面板点选、触发器只读，不启用块级智能录入（与 OpenSpec 一致） */
export declare const MANUAL_INPUT_DISABLED_PICKER_TYPES: readonly ["week", "dates", "months", "years", "quarters", "quarter", "quarterrange"];
export declare function isManualInputDisabledPickerType(type: string): boolean;
export declare const DEFAULT_FORMATS_DATEPICKER: {
    date: string;
    dates: string;
    week: string;
    year: string;
    years: string;
    month: string;
    months: string;
    quarter: string;
    quarters: string;
    datetime: string;
    monthrange: string;
    yearrange: string;
    quarterrange: string;
    daterange: string;
    datetimerange: string;
};
export type TimeUnit = typeof timeUnits[number];
