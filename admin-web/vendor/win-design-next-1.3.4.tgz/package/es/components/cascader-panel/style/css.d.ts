import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-cascader-panel.css';
import 'win-design-next/es/components/checkbox/style/css';
import 'win-design-next/es/components/radio/style/css';
import 'win-design-next/es/components/scrollbar/style/css';
