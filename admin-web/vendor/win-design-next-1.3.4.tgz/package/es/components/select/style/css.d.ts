import 'win-design-next/es/components/base/style/css';
import 'win-design-next/es/components/tag/style/css';
import 'win-design-next/es/components/option/style/css';
import 'win-design-next/es/components/option-group/style/css';
import 'win-design-next/es/components/scrollbar/style/css';
import 'win-design-next/es/components/popper/style/css';
import 'win-design-next/theme-chalk/w-select.css';
