import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
import type { Arrayable, Awaitable } from 'win-design-next/es/utils';
export type CollapseActiveName = string | number;
export type CollapseModelValue = Arrayable<CollapseActiveName>;
export type CollapseIconPositionType = 'left' | 'right';
export declare const emitChangeFn: (value: CollapseModelValue) => value is string | number | CollapseActiveName[];
export declare const collapseProps: {
    readonly accordion: BooleanConstructor;
    readonly modelValue: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number | CollapseActiveName[]) | (() => CollapseModelValue) | ((new (...args: any[]) => string | number | CollapseActiveName[]) | (() => CollapseModelValue))[], unknown, unknown, () => [], boolean>;
    readonly round: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly border: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly size: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "mini" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly plain: BooleanConstructor;
    readonly expandIconPosition: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => "left" | "right") | (() => CollapseIconPositionType) | ((new (...args: any[]) => "left" | "right") | (() => CollapseIconPositionType))[], unknown, unknown, "right", boolean>;
    readonly beforeCollapse: {
        readonly type: import("vue").PropType<(name: CollapseActiveName) => Awaitable<boolean>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
};
export type CollapseProps = ExtractPropTypes<typeof collapseProps>;
export type CollapsePropsPublic = ExtractPublicPropTypes<typeof collapseProps>;
export declare const collapseEmits: {
    "update:modelValue": (value: CollapseModelValue) => value is string | number | CollapseActiveName[];
    change: (value: CollapseModelValue) => value is string | number | CollapseActiveName[];
};
export type CollapseEmits = typeof collapseEmits;
