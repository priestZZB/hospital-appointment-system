import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
import type { CollapseActiveName } from './collapse';
export declare const collapseItemProps: {
    readonly title: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly name: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | number) | (() => CollapseActiveName) | ((new (...args: any[]) => string | number) | (() => CollapseActiveName))[], unknown, unknown, undefined, boolean>;
    readonly icon: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<ExtractPropTypes<{}>>, {}, {}>, boolean>;
    readonly disabled: BooleanConstructor;
};
export type CollapseItemProps = ExtractPropTypes<typeof collapseItemProps>;
export type CollapseItemPropsPublic = ExtractPublicPropTypes<typeof collapseItemProps>;
