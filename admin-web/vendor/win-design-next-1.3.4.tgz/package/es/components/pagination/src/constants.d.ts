import type { ComputedRef, InjectionKey, WritableComputedRef } from 'vue';
export interface WPaginationContext {
    currentPage?: WritableComputedRef<number>;
    pageCount?: ComputedRef<number>;
    disabled?: ComputedRef<boolean>;
    changeEvent?: (val: number) => void;
    handleSizeChange?: (val: number) => void;
}
export declare const wPaginationKey: InjectionKey<WPaginationContext>;
