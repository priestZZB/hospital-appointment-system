import type { AriaProps, UseDelayedToggleProps } from 'win-design-next/es/hooks';
import type { PopperContentProps } from 'win-design-next/es/components/popper';
import type TooltipContent from './content.vue';
import type { ExtractPublicPropTypes } from 'vue';
export interface WTooltipContentProps extends UseDelayedToggleProps, Omit<PopperContentProps, 'visible'> {
    /**
     * @description which element the tooltip CONTENT appends to
     */
    appendTo?: string | HTMLElement;
    /**
     * @description display content, can be overridden by `slot#content`
     */
    content?: string;
    /**
     * @description whether `content` is treated as HTML string
     */
    rawContent?: boolean;
    /**
     * @description when tooltip inactive and `persistent` is `false` , popconfirm will be destroyed
     */
    persistent?: boolean;
    /**
     * @description visibility of Tooltip
     */
    visible?: boolean | null;
    /**
     * @description animation name
     */
    transition?: string;
    /**
     * @description whether tooltip content is teleported, if `true` it will be teleported to where `append-to` sets
     */
    teleported?: boolean;
    /**
     * @description whether Tooltip is disabled
     */
    disabled?: boolean;
    ariaLabel?: AriaProps['ariaLabel'];
}
export declare const useTooltipContentPropsDefaults: {
    readonly content: "";
    readonly visible: null;
    readonly teleported: true;
    readonly effect: "lighter";
    readonly enterable: true;
    readonly stopPopperMouseEvent: true;
    readonly pure: false;
    readonly focusOnShow: false;
    readonly trapping: false;
    readonly virtualTriggering: false;
    readonly loop: false;
    readonly style: undefined;
    readonly popperStyle: undefined;
    readonly popperClass: undefined;
    readonly arrowOffset: 5;
    readonly boundariesPadding: 0;
    readonly gpuAcceleration: true;
    readonly offset: 12;
    readonly placement: "bottom";
    readonly popperOptions: () => {};
    readonly strategy: "absolute";
    readonly showAfter: 0;
    readonly hideAfter: 200;
    readonly autoClose: 0;
};
/**
 * @deprecated Removed after 3.0.0, Use `WTooltipContentProps` instead.
 */
export declare const useTooltipContentProps: {
    readonly ariaLabel: StringConstructor;
    readonly appendTo: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | ((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly content: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly rawContent: BooleanConstructor;
    readonly persistent: BooleanConstructor;
    readonly visible: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | null) | ((new (...args: any[]) => boolean) | (() => boolean | null))[], unknown, unknown, null, boolean>;
    readonly transition: StringConstructor;
    readonly teleported: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly disabled: BooleanConstructor;
    readonly loop: BooleanConstructor;
    readonly id: StringConstructor;
    readonly style: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly className: {
        readonly type: import("vue").PropType<import("win-design-next/es/utils").EpPropMergeType<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly effect: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect) | ((new (...args: any[]) => string) | (() => import("win-design-next/es/components/popper").PopperEffect))[], unknown, unknown, "lighter", boolean>;
    readonly enterable: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pure: BooleanConstructor;
    readonly focusOnShow: BooleanConstructor;
    readonly trapping: BooleanConstructor;
    readonly popperClass: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("win-design-next/es/utils").ClassValue[]) | (() => import("win-design-next/es/utils").ClassValue))[], unknown, unknown, undefined, boolean>;
    readonly popperStyle: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, undefined, boolean>;
    readonly referenceEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly triggerTargetEl: {
        readonly type: import("vue").PropType<HTMLElement>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly stopPopperMouseEvent: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly virtualTriggering: BooleanConstructor;
    readonly zIndex: NumberConstructor;
    readonly arrowOffset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 5, boolean>;
    readonly boundariesPadding: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fallbackPlacements: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]) | ((new (...args: any[]) => import("win-design-next/es/components/popper").Placement[]) | (() => import("win-design-next/es/components/popper").Placement[]))[], unknown, unknown, undefined, boolean>;
    readonly gpuAcceleration: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly offset: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 12, boolean>;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, import("win-design-next/es/components/popper").Placement, unknown, "bottom", boolean>;
    readonly popperOptions: import("win-design-next/es/utils").EpPropFinalized<(new (...args: any[]) => Partial<import("win-design-next/es/components/popper").Options>) | (() => Partial<import("win-design-next/es/components/popper").Options>) | ((new (...args: any[]) => Partial<import("win-design-next/es/components/popper").Options>) | (() => Partial<import("win-design-next/es/components/popper").Options>))[], unknown, unknown, () => {}, boolean>;
    readonly strategy: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, "fixed" | "absolute", unknown, "absolute", boolean>;
    readonly showAfter: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly hideAfter: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 200, boolean>;
    readonly autoClose: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
};
/**
 * @deprecated Removed after 3.0.0, Use `WTooltipContentProps` instead.
 */
export type WTooltipContentPropsPublic = ExtractPublicPropTypes<typeof useTooltipContentProps>;
export type TooltipContentInstance = InstanceType<typeof TooltipContent> & unknown;
