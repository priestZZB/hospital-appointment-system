import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-table.css';
import 'win-design-next/es/components/checkbox/style/css';
import 'win-design-next/es/components/tooltip/style/css';
import 'win-design-next/es/components/scrollbar/style/css';
