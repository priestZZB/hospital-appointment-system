import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-slider.css';
import 'win-design-next/es/components/input-number/style/css';
import 'win-design-next/es/components/tooltip/style/css';
