declare const __VLS_export: import("vue").DefineComponent<{
    readonly modelValue: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly vertical: BooleanConstructor;
    readonly tooltipClass: StringConstructor;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, import("win-design-next").Placement, unknown, "top", boolean>;
}, {
    onButtonDown: (event: MouseEvent | TouchEvent) => void;
    onKeyDown: (event: KeyboardEvent) => void;
    setPosition: (newPosition: number) => Promise<void>;
    hovering: import("vue").Ref<boolean>;
    dragging: import("vue").Ref<boolean>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: number) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly vertical: BooleanConstructor;
    readonly tooltipClass: StringConstructor;
    readonly placement: import("win-design-next/es/utils").EpPropFinalized<StringConstructor, import("win-design-next").Placement, unknown, "top", boolean>;
}>> & {
    "onUpdate:modelValue"?: ((value: number) => any) | undefined;
}, {
    readonly vertical: boolean;
    readonly modelValue: number;
    readonly placement: import("win-design-next/es/utils").EpPropMergeType<StringConstructor, import("win-design-next").Placement, unknown>;
}, {}>;
declare const _default: typeof __VLS_export;
export default _default;
