import 'win-design-next/es/components/base/style/css';
import 'win-design-next/es/components/input/style/css';
import 'win-design-next/es/components/button/style/css';
import 'win-design-next/es/components/checkbox/style/css';
import 'win-design-next/es/components/checkbox-group/style/css';
import 'win-design-next/theme-chalk/w-transfer.css';
