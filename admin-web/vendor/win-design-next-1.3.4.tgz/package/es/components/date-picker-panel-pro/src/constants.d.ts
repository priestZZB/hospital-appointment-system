import type { InjectionKey, SetupContext } from 'vue';
import type { UseNamespaceReturn } from 'win-design-next/es/hooks';
interface DatePickerContext {
    slots: SetupContext['slots'];
    pickerNs: UseNamespaceReturn;
}
export declare const ROOT_PICKER_INJECTION_KEY: InjectionKey<DatePickerContext>;
/**
 * @deprecated 已废弃：智能录入重构后不再 provide 该注入，仅为兼容 v1.3.2 前的既有导入保留
 */
export declare const ROOT_PICKER_IS_DEFAULT_FORMAT_INJECTION_KEY = "WIsDefaultFormat";
export {};
