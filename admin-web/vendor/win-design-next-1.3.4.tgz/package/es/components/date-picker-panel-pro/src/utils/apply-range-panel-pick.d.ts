import type { Ref } from 'vue';
import type { Dayjs } from 'dayjs';
type RangePickPayload = {
    minDate: Dayjs;
    maxDate: Dayjs | null;
};
type RangePanelEmit = {
    (e: 'pick', value: [Dayjs, Dayjs], visible?: boolean): void;
    (e: 'calendar-change', value: [Date, Date | null]): void;
};
/** 范围面板统一处理 { minDate, maxDate }：未完成只发 calendar-change，完成才更新 model */
export declare function applyRangePanelPick(payload: RangePickPayload, minDate: Ref<Dayjs | null>, maxDate: Ref<Dayjs | null>, focusType: Ref<'start' | 'end'>, emit: RangePanelEmit): void;
export declare function isRangePickPayload(payload: unknown): payload is RangePickPayload;
export {};
