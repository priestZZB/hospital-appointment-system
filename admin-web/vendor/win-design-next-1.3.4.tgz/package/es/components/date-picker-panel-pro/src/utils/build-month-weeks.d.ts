import type { Dayjs } from 'dayjs';
import type { DateCell } from '../types';
import type { CellClassNameType } from '../props/shared';
export type BuildMonthWeeksOptions = {
    year: number;
    month: number;
    lang: string;
    firstDayOfWeek?: number;
    showWeekNumber?: boolean;
    disabled?: boolean;
    disabledDate?: (date: Date) => boolean;
    minDate?: Dayjs | null;
    maxDate?: Dayjs | null;
    parsedValue?: Dayjs | Dayjs[] | null;
    selectionMode?: string;
    cellClassName?: CellClassNameType;
};
export declare function buildMonthDisplayWeeks(options: BuildMonthWeeksOptions): DateCell[][];
