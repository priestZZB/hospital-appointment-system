import type { Dayjs } from 'dayjs';
import type { DateCell } from '../types';
export interface YearMonthIndexItem {
    year: number;
    month?: number;
    isMonth: boolean;
    active: boolean;
    flowId: string | number;
}
export interface MonthIndexItem {
    year: number;
    month: number;
    flowId: string;
}
export type DisplayWeekRow = DateCell[];
export interface CalendarRangeContext {
    startYear: number;
    endYear: number;
}
export type CalendarAnchorInput = Dayjs | undefined | null | [Dayjs | undefined | null, Dayjs | undefined | null];
