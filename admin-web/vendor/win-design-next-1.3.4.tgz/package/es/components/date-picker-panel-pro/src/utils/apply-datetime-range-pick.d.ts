import type { Ref } from 'vue';
import type { Dayjs } from 'dayjs';
type RangePickPayload = {
    minDate: Dayjs;
    maxDate: Dayjs | null;
};
type DatetimeRangePanelEmit = {
    (e: 'pick', value: [Dayjs, Dayjs], visible?: boolean): void;
    (e: 'calendar-change', value: [Date, Date | null]): void;
};
/** datetimerange：以 resolveRangeCellPick 的 payload 为准，再按时间先后 normalize */
export declare function applyDatetimeRangePanelPick(payload: RangePickPayload, minDate: Ref<Dayjs | null>, maxDate: Ref<Dayjs | null>, _focusType: Ref<'start' | 'end'>, emit: DatetimeRangePanelEmit): void;
export {};
