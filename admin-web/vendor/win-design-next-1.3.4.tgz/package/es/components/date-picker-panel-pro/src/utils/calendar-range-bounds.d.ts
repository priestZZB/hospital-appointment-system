import type { Dayjs } from 'dayjs';
export type CalendarYearRange = {
    startYear: number;
    endYear: number;
};
export declare const CALENDAR_RANGE_COMPONENT = "WDatePickerPanelPro";
/** 默认年份窗口：当前年 ±10（仅用于 prop 默认值与非法入参回退） */
export declare function getDefaultCalendarRange(): [number, number];
/** 规范化 [startYear, endYear]，无效时返回 undefined */
export declare function normalizeCalendarRange(range?: [number, number] | null): [number, number] | undefined;
/**
 * 解析 calendarRange：有效则原样使用；未传则用默认值；显式传入非法/空数组时告警并回退默认。
 */
export declare function resolveCalendarRange(raw?: [number, number] | null, componentName?: string): [number, number];
export declare function isYearInCalendarRange(year: number, startYear: number, endYear: number): boolean;
export declare function clampYearToCalendarRange(year: number, startYear: number, endYear: number): number;
export declare function calendarRangeToDisplayYears(range: [number, number]): CalendarYearRange;
/** 将 default-value 锚点年份并入 calendarRange，避免默认 ±10 窗口无法滚动到目标年 */
export declare function expandCalendarRangeForAnchor(range: [number, number], anchor?: Date | Date[] | null): [number, number];
/** 将 dayjs 年份限制在 calendarRange 内（保留月日时分秒） */
export declare function clampDayjsToCalendarRange(value: Dayjs, range: [number, number]): Dayjs;
/** 解析结果（单值或范围）统一按 calendarRange 钳制年份 */
export declare function clampParsedValueToCalendarRange(value: Dayjs | Dayjs[], range: [number, number]): Dayjs | Dayjs[];
