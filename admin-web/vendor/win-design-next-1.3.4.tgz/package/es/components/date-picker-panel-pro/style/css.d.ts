import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-date-picker-pro.css';
import 'win-design-next/es/components/virtual-list/style/css';
import 'win-design-next/es/components/tabs/style/css';
import 'win-design-next/es/components/input/style/css';
import 'win-design-next/es/components/scrollbar/style/css';
import 'win-design-next/es/components/button/style/css';
