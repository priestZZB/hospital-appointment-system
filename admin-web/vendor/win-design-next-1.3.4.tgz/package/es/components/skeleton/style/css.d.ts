import 'win-design-next/es/components/base/style/css';
import 'win-design-next/theme-chalk/w-skeleton.css';
import 'win-design-next/es/components/skeleton-item/style/css';
