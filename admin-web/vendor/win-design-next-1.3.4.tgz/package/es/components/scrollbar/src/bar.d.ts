import type { ExtractPropTypes, ExtractPublicPropTypes } from 'vue';
import type Bar from './bar.vue';
export declare const barProps: {
    readonly always: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly minSize: {
        readonly type: import("vue").PropType<number>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly hScrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
    readonly scrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
};
export type BarProps = ExtractPropTypes<typeof barProps>;
export type BarPropsPublic = ExtractPublicPropTypes<typeof barProps>;
export type BarInstance = InstanceType<typeof Bar> & unknown;
