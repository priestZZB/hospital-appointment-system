declare const __VLS_export: import("vue").DefineComponent<{
    readonly always: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly minSize: {
        readonly type: import("vue").PropType<number>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly hScrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
    readonly scrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
}, {
    handleScroll: (wrap: HTMLDivElement) => void;
    update: () => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly always: import("win-design-next/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly minSize: {
        readonly type: import("vue").PropType<number>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly hScrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
    readonly scrollbarSize: import("win-design-next/es/utils").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
}>>, {
    readonly always: import("win-design-next/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly hScrollbarSize: number;
    readonly scrollbarSize: number;
}, {}>;
declare const _default: typeof __VLS_export;
export default _default;
